
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bonaternos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agenda`
--

CREATE DATABASE SIGENBonaternos;

USE SIGENBonaternos;

CREATE TABLE `agenda` (
  `Institucion` int NOT NULL,
  `Dia_Semana` varchar (7) NOT NULL,
  `Hora_Inicio` int NOT NULL,
  `Hora_Final` int NOT NULL
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asigna`
--

CREATE TABLE `asigna` (
  Id_Entrenador int(11) NOT NULL,
  Id_Combo int(11) NOT NULL,
  Tipo_Doc varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL,
  PRIMARY KEY (Tipo_Doc, Nº_Doc, Id_Combo)
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `atiende`
--

CREATE TABLE atiende (
  Tipo_Doc varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL,
  Id int(11) UNIQUE,
  PRIMARY KEY (Tipo_Doc, Nº_Doc)
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calificacion`
--

CREATE TABLE `calificacion` (
  `Puntaje` int(11) NOT NULL,
  `ID` int (11) NOT NULL,	
  `Desempenios` varchar(100) NOT NULL,
  `Item` varchar(15) NOT NULL
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE cliente (
  Tipo_Doc varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL,
  Primer_apellido varchar(40) NOT NULL,
  Segundo_apellido varchar(40) NOT NULL,
  Nombre varchar(40) NOT NULL,
  Edad int(3) NOT NULL,
  Numero_de_puerta int (4) NOT NULL,
  Calle varchar (35) NOT NULL,
  Esquina varchar (35) NOT NULL,
  PRIMARY KEY (Tipo_Doc, Nº_Doc)  -- Definir clave primaria compuesta
);

-- Crear la tabla cliente_telefonos
CREATE TABLE cliente_telefonos (
    Tipo_Doc varchar(10) NOT NULL,
    Nº_Doc int(11) NOT NULL,
    Telefono varchar(9) NOT NULL,  -- Usar varchar(15) para manejar formatos de teléfono más flexibles
    PRIMARY KEY (Tipo_Doc, Nº_Doc, Telefono),  -- Clave primaria compuesta para evitar duplicados
    FOREIGN KEY (Tipo_Doc, Nº_Doc) REFERENCES cliente (Tipo_Doc, Nº_Doc)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `combina`
--

CREATE TABLE `combina` (
  `Id_Entrenador` varchar(10) NOT NULL,
  `Id_Combo` int(11) NOT NULL,
  `Nombre` varchar(10) NOT NULL
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `combo`
--

CREATE TABLE `Equipo` (
  `Nombre` varchar(10)NOT NULL,
  `Deporte` varchar (8)NOT NULL
);

CREATE TABLE `Selecciona` (
  `Nombre` varchar(10) NOT NULL,
  `Tipo_Doc` varchar(10) NOT NULL,
  `Nº_Doc` int(11) NOT NULL
);

CREATE TABLE `combo` (
  `Id` int(11) NOT NULL,
  `Ejercicios` int(11) NOT NULL
)  ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consulta`
--

CREATE TABLE `consulta` (
  `Fecha` date NOT NULL,
  `Institucion` int NOT NULL,
  `Tipo_Doc` varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deportista`
--

CREATE TABLE `deportista` (
  `Tipo_Doc` varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL,
  `Peso` varchar(11) NOT NULL,
  `Actividad` varchar(20) NOT NULL,
  `Posicion` varchar(10) NOT NULL
) ; 
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `depto`
--

CREATE TABLE `depto` (
  `Nombre` varchar(15) NOT NULL
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `d_fisio`
--

CREATE TABLE `d_fisio` (
  `Area_a_Fortalecer` varchar(10) NOT NULL,
  `Tipo_Doc` varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL
) ;
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ejercicios`
--

CREATE TABLE `ejercicios` (
  `Nombre` varchar(10) NOT NULL,
  `Grupo_Muscular` varchar(10) NOT NULL,
  `Especificacion` varchar(10) NOT NULL
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entrenador`
--


CREATE TABLE `entrenador` (
  Tipo_Doc varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL,
  Id int(11) UNIQUE,
  Primer_apellido varchar(40) NOT NULL,
  Segundo_apellido varchar(40),
  Nombre varchar(40) NOT NULL,
  Edad int (3) NOT NULL,
  Id_Sucursal int(11) NOT NULL,
  Turno varchar(8) NOT NULL,
  PRIMARY KEY (Tipo_Doc, Nº_Doc, Id)  -- Definir clave primaria compuesta
) ;
-- Crear la tabla cliente_telefonos
CREATE TABLE entrenador_telefonos (
    Tipo_Doc varchar(10) NOT NULL,
    Nº_Doc int(11) NOT NULL,
    Telefono varchar(9) NOT NULL,  -- Usar varchar(15) para manejar formatos de teléfono más flexibles
    PRIMARY KEY (Tipo_Doc, Nº_Doc, Telefono),  -- Clave primaria compuesta para evitar duplicados
    FOREIGN KEY (Tipo_Doc, Nº_Doc) REFERENCES entrenador (Tipo_Doc, Nº_Doc)
);
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `esta`
--

CREATE TABLE `esta` (
  `Numero` int(11) NOT NULL,
  `Nombre` varchar(15) NOT NULL
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE `estado` (

  `Tipo_Estado` varchar(8) NOT NULL
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hace`
--

CREATE TABLE `hace` (
  `Nombre` varchar(10) NOT NULL,
  `Tipo_Doc` varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL
)  ;


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pago`
--

CREATE TABLE `pago` (
  `Fecha` date NOT NULL,
  `Ultimo_Mes_Abonado` date NOT NULL
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pasa`
--

CREATE TABLE `pasa` (
  `Tipo_DocCliente` varchar(10) NOT NULL,
  `Nº_DocCliente` int(11) NOT NULL,
  `Inicio_Estado` varchar(20) DEFAULT NULL,
  `Final_Estado` varchar(20) DEFAULT NULL,
  `Tipo_Estado` varchar (20)  
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `realiza`
--

CREATE TABLE `realiza` (
  `Tipo_Doc` varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL,
  `Fecha` date NOT NULL
) ;
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recibe`
--

CREATE TABLE `recibe` (
  `Fecha_inicio` date NOT NULL,
  `Fecha_Final` date NOT NULL,
  `Id` int (11) NOT NULL,
  `Tipo_Doc` varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sucursal`
--

CREATE TABLE `sucursal` (
  `Numero` int(11) NOT NULL,
  `Nombre` varchar(15) NOT NULL,
  `Esquina` varchar(35) NOT NULL,
  `Calle` varchar(35) NOT NULL,
  `Nro de puerta` int(4) NOT NULL,
  `Capacidad` int(11) NOT NULL
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tiene`
--

CREATE TABLE `tiene` (
  `Institucion` int NOT NULL,
  `Numero` int(11) NOT NULL
); 
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usa`
--

CREATE TABLE `usa` (
  Id_Combo int(11) NOT NULL,
  Tipo_Doc varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL,
  PRIMARY KEY (Tipo_Doc, Nº_Doc, Id_Combo)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Asiste`
--

CREATE TABLE `asiste` (
  Nombre varchar(15) NOT NULL,
  Numero int(11) NOT NULL,
  Tipo_Doc varchar(10) NOT NULL,
  Nº_Doc int(11) NOT NULL,
  PRIMARY KEY (Nombre, Numero)
);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `agenda`
--
ALTER TABLE `agenda`
  ADD PRIMARY KEY (`Institucion`);


--
-- Indices de la tabla `calificacion`
--
ALTER TABLE `calificacion`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `cliente`
--

--
-- Indices de la tabla `combina`
--
ALTER TABLE `combina`
  ADD PRIMARY KEY (`Id_Entrenador`,`Id_Combo`),
  ADD KEY `Nombre` (`Nombre`);

--
-- Indices de la tabla `combo`
--
ALTER TABLE `combo`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `consulta`
--
ALTER TABLE `consulta`
  ADD PRIMARY KEY (`Tipo_Doc`,`Nº_Doc`),
  ADD KEY `Institucion` (`Institucion`);

--
-- Indices de la tabla `deportista`
--
ALTER TABLE `deportista`
  ADD PRIMARY KEY (`Tipo_Doc`,`Nº_Doc`);

--
-- Indices de la tabla `depto`
--
ALTER TABLE `depto`
  ADD PRIMARY KEY (`Nombre`);

--
-- Indices de la tabla `d_fisio`
--
ALTER TABLE `d_fisio`
  ADD PRIMARY KEY (`Tipo_Doc`,`Nº_Doc`);

--
-- Indices de la tabla `ejercicios`
--
ALTER TABLE `ejercicios`
  ADD PRIMARY KEY (`Nombre`);

--
--
-- Indices de la tabla `esta`
--
ALTER TABLE `esta`
  ADD PRIMARY KEY (`Numero`),
  ADD KEY `Nombre` (`Nombre`);

--
-- Indices de la tabla `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`Tipo_Estado`);

--
-- Indices de la tabla `hace`
--
ALTER TABLE `hace`
  ADD PRIMARY KEY (`Nombre`,`Tipo_Doc`,`Nº_Doc`),
  ADD KEY `Tipo_Doc` (`Tipo_Doc`,`Nº_Doc`);

--
-- Indices de la tabla `pago`
--
ALTER TABLE `pago`
  ADD PRIMARY KEY (`Fecha`);

--
-- Indices de la tabla `pasa`
--
ALTER TABLE `pasa`
  ADD PRIMARY KEY (`Tipo_Estado`),
  ADD KEY `Tipo_DocCliente` (`Tipo_DocCliente`,`Nº_DocCliente`);

--
-- Indices de la tabla `realiza`
--
ALTER TABLE `realiza`
  ADD PRIMARY KEY (`Tipo_Doc`,`Nº_Doc`),
  ADD KEY `Fecha` (`Fecha`);

--
-- Indices de la tabla `recibe`
--
ALTER TABLE `recibe`
  ADD PRIMARY KEY (`Tipo_Doc`,`Nº_Doc`),
  ADD KEY (`Id`);

--
-- Indices de la tabla `sucursal`
--
ALTER TABLE `sucursal`
  ADD PRIMARY KEY (`Numero`);

--
-- Indices de la tabla `tiene`
--
ALTER TABLE `tiene`
  ADD PRIMARY KEY (`Numero`),
  ADD KEY `Institucion` (`Institucion`);


--
-- Filtros para la tabla `asigna`
--
ALTER TABLE `asigna`
  ADD CONSTRAINT `asigna_ibfk_1` FOREIGN KEY (Id_Entrenador) REFERENCES entrenador (Id),
  ADD CONSTRAINT `asigna_ibfk_2` FOREIGN KEY (Tipo_Doc, Nº_Doc, Id_Combo) REFERENCES `usa` (Tipo_Doc, Nº_Doc, Id_Combo);

--
-- Filtros para la tabla `atiende`
--

--
-- Filtros para la tabla `combina`
--
ALTER TABLE `combina`
  ADD CONSTRAINT `combina_ibfk_1` FOREIGN KEY (`Id_Combo`) REFERENCES `combo` (`Id`),
  ADD CONSTRAINT `combina_ibfk_2` FOREIGN KEY (`Nombre`) REFERENCES `ejercicios` (`Nombre`);

--
-- Filtros para la tabla `consulta`
--
ALTER TABLE `consulta`
  ADD CONSTRAINT `consulta_ibfk_1` FOREIGN KEY (`Institucion`) REFERENCES `agenda` (`Institucion`),
  ADD CONSTRAINT `consulta_ibfk_2` FOREIGN KEY (`Tipo_Doc`,`Nº_Doc`) REFERENCES `cliente` (`Tipo_Doc`, `Nº_Doc`);

--
-- Filtros para la tabla `esta`
--
ALTER TABLE `esta`
  ADD CONSTRAINT `esta_ibfk_1` FOREIGN KEY (`Numero`) REFERENCES `sucursal` (`Numero`),
  ADD CONSTRAINT `esta_ibfk_2` FOREIGN KEY (`Nombre`) REFERENCES `depto` (`Nombre`),
  ADD CONSTRAINT `esta_ibfk_3` FOREIGN KEY (`Numero`) REFERENCES `sucursal` (`Numero`),
  ADD CONSTRAINT `esta_ibfk_4` FOREIGN KEY (`Nombre`) REFERENCES `depto` (`Nombre`),
  ADD CONSTRAINT `esta_ibfk_5` FOREIGN KEY (`Numero`) REFERENCES `sucursal` (`Numero`),
  ADD CONSTRAINT `esta_ibfk_6` FOREIGN KEY (`Nombre`) REFERENCES `depto` (`Nombre`);

--
-- Filtros para la tabla `hace`
--
ALTER TABLE `hace`
  ADD CONSTRAINT `hace_ibfk_1` FOREIGN KEY (`Tipo_Doc`,`Nº_Doc`) REFERENCES `d_fisio` (`Tipo_Doc`, `Nº_Doc`),
  ADD CONSTRAINT `hace_ibfk_2` FOREIGN KEY (`Nombre`) REFERENCES `ejercicios` (`Nombre`);

--
-- Filtros para la tabla `pasa`
--
ALTER TABLE `pasa`
  ADD CONSTRAINT `pasa_ibfk_1` FOREIGN KEY (`Tipo_Estado`) REFERENCES `estado` (`Tipo_Estado`),
  ADD CONSTRAINT `pasa_ibfk_2` FOREIGN KEY (`Tipo_DocCliente`,`Nº_DocCliente`) REFERENCES `cliente` (`Tipo_Doc`, `Nº_Doc`);

--
-- Filtros para la tabla `realiza`
--
ALTER TABLE `realiza`
  ADD CONSTRAINT `realiza_ibfk_1` FOREIGN KEY (`Tipo_Doc`,`Nº_Doc`) REFERENCES `cliente` (`Tipo_Doc`, `Nº_Doc`),
  ADD CONSTRAINT `realiza_ibfk_2` FOREIGN KEY (`Fecha`) REFERENCES `pago` (`Fecha`);

--
-- Filtros para la tabla `recibe`
--
ALTER TABLE `recibe`
  ADD CONSTRAINT `recibe_ibfk_1` FOREIGN KEY (`Id`) REFERENCES `calificacion` (`ID`),
  ADD CONSTRAINT `recibe_ibfk_2` FOREIGN KEY (`Tipo_Doc`,`Nº_Doc`) REFERENCES `cliente` (`Tipo_Doc`, `Nº_Doc`);

--
-- Filtros para la tabla `tiene`
--
ALTER TABLE `tiene`
  ADD CONSTRAINT `tiene_ibfk_1` FOREIGN KEY (`Institucion`) REFERENCES `agenda` (`Institucion`),
  ADD CONSTRAINT `tiene_ibfk_2` FOREIGN KEY (`Numero`) REFERENCES `esta` (`Numero`),
  ADD CONSTRAINT `tiene_ibfk_3` FOREIGN KEY (`Institucion`) REFERENCES `agenda` (`Institucion`),
  ADD CONSTRAINT `tiene_ibfk_4` FOREIGN KEY (`Numero`) REFERENCES `esta` (`Numero`);

--
-- Filtros para la tabla `usa`
--
ALTER TABLE `usa`
  ADD CONSTRAINT `usa_ibfk_1` FOREIGN KEY (Id_Combo) REFERENCES `combo` (`Id`),
  ADD CONSTRAINT `usa_ibfk_2` FOREIGN KEY (`Tipo_Doc`,`Nº_Doc`) REFERENCES `deportista` (`Tipo_Doc`, `Nº_Doc`);

--
-- Filtros para la tabla `asiste`
--
ALTER TABLE `asiste`
  ADD CONSTRAINT `asiste_ibfk_1` FOREIGN KEY (Nombre, Numero) REFERENCES esta (Nombre, Numero),
  ADD CONSTRAINT `asiste_ibfk_2` FOREIGN KEY (Tipo_Doc,Nº_Doc) REFERENCES cliente (Tipo_Doc, Nº_Doc);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

ALTER TABLE atiende
  ADD FOREIGN KEY (Id) REFERENCES entrenador (Id),
  ADD FOREIGN KEY (Tipo_Doc, Nº_Doc) REFERENCES cliente (Tipo_Doc, Nº_Doc);



-- usuario deportista
CREATE USER '12345678'@'localhost' IDENTIFIED BY 'micontra';
GRANT SELECT, UPDATE on SIGENBonaternos.* to '12345678'@'localhost' ;

INSERT INTO cliente (Tipo_Doc, Nº_Doc, Primer_apellido, Segundo_apellido, Nombre, Edad, Numero_de_puerta, Calle, Esquina) 
VALUES ('CI', 12345678, 'Escobar', 'Garcia', 'Francisco', 20, 293, 'WaosQKalle', 'OMG');

INSERT INTO cliente_telefonos (Tipo_Doc, Nº_Doc, Telefono) 
VALUES ('CI', 12345678, '09001920');

INSERT INTO deportista (Tipo_Doc, Nº_Doc, Actividad, Peso, Posicion) 
VALUES ('CI', 12345678, 'Comedor de panchos', '11', 'Ganador');





-- usuario entrenador
CREATE USER '56342206'@'localhost' IDENTIFIED BY 'hola123';
GRANT SELECT, UPDATE on SIGENBonaternos.* to '56342206'@'localhost';

INSERT INTO entrenador (Tipo_Doc, Nº_Doc, Id, Primer_apellido, Segundo_apellido, Nombre, Edad, Id_Sucursal, Turno) VALUES ('CI', 56342206, 38, 'Nanoide', 'Goku', 'Mauro', '19', 10, 'Tarde');
INSERT INTO entrenador_telefonos (Tipo_Doc, Nº_Doc, Telefono) VALUES ('CI', 56342206, '093677572');



-- usuario d_fisio

CREATE USER '56802231'@'localhost' IDENTIFIED BY 'contrasenia123';
GRANT SELECT, UPDATE on SIGENBonaternos.* to '56802231'@'localhost';

INSERT INTO cliente (Tipo_Doc, Nº_Doc, Primer_apellido, Segundo_apellido, Nombre, Edad, Numero_de_puerta, Calle, Esquina) VALUES ('CI', 56802231, 'Cirio', 'Martinez', 'Carlos', 40, 135, 'Jose Ramirez', 'Jose ruis');
INSERT INTO cliente_telefonos (Tipo_Doc, Nº_Doc, Telefono) VALUES ('CI', 56802231, '099384806');
INSERT INTO d_fisio(Area_a_Fortalecer, Tipo_Doc, Nº_Doc) VALUES ('Cabeza', 'CI', 56802231);


CREATE USER 'Administrador'@'localhost' IDENTIFIED BY 'contraseñasegura';
GRANT SELECT, INSERT, UPDATE, 	DELETE, ALTER on SIGENBonaternos.* to '56802231'@'localhost';